package com.onlinebanking.Service;

import java.util.ArrayList;

import Exception.OnlineBankingException;

import com.onlinebanking.Bean.OnlineBankingBean;
import com.onlinebanking.Dao.IonlineBankingDao;
import com.onlinebanking.Dao.OnlineBankingDao;

public class OnlineBankingService implements IonlineBankingService{

	@Override
	public ArrayList<Long> getAccounts(long acc_no) throws OnlineBankingException {
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<Long> accounts=new ArrayList<Long>();
		accounts=ibd.getAccounts(acc_no);
		return accounts;
	}

	@Override
	public String getEmailId(long accountNo) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String email=ibd.getEmailId(accountNo);
		return email;
	}

	@Override
	public String updateEmail(long acc_no, String email, String existingemail) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String updateEmailId=ibd.getEmailId(acc_no,email,existingemail);
		return updateEmailId;
	}

	@Override
	public String getAddress(long accountNo) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String address=ibd.getAddress(accountNo);
		return address;
	}
	@Override
	public String updateAddress(long acc_no, String address, String existingAddress) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String updateEmailId=ibd.getAddressUpdate(acc_no,address,existingAddress);
		return updateEmailId;
	}

	@Override
	public String raiseCheckBookRequest(long accountNo, String description) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String raiseCheckBookRequest=ibd.raiseCheckBookRequest(accountNo,description);
		return raiseCheckBookRequest;
	}

	@Override
	public ArrayList<OnlineBankingBean> getCheckBookService(long service_id) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<OnlineBankingBean> serviceRequestDetails=new ArrayList<OnlineBankingBean>();
		serviceRequestDetails=ibd.getServiceRequestDetails(service_id);
		return serviceRequestDetails;
	}

	@Override
	public ArrayList<Long> getPayeeAccounts(long uid) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<Long> PayeeAccounts=ibd.getPayeeAccounts(uid);
		return PayeeAccounts;
	}

	@Override
	public String transferFunds(long accountNo, long payeeAccount,
			String transferDesc,long amount,String transpwd) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String transferFunds=ibd.transferFunds(accountNo,payeeAccount,transferDesc,amount,transpwd);
		return transferFunds;
	}

	@Override
	public ArrayList<OnlineBankingBean> getCheckBookAccountService(long acc_no) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<OnlineBankingBean> AccountserviceRequestDetails=new ArrayList<OnlineBankingBean>();
		AccountserviceRequestDetails=ibd.getAccountServiceRequestDetails(acc_no);
		return AccountserviceRequestDetails;
	}

	@Override
	public String createAccount(OnlineBankingBean ob) {
		IonlineBankingDao ibd=new OnlineBankingDao();
		String createAccount=ibd.createAccount(ob);
		return createAccount;
	}

	@Override
	public ArrayList<OnlineBankingBean> getYearlyTransaction(int year) {
		ArrayList<OnlineBankingBean> transactionYear=new ArrayList<OnlineBankingBean>();
		IonlineBankingDao ibd=new OnlineBankingDao();
		transactionYear=ibd.getTransactionYear(year);
		return transactionYear;
	}
	@Override
	public ArrayList<OnlineBankingBean> getMonthlyTransaction(int month) {
		ArrayList<OnlineBankingBean> transactionMonth=new ArrayList<OnlineBankingBean>();
		IonlineBankingDao ibd=new OnlineBankingDao();
		transactionMonth=ibd.getTransactionMonth(month);
		return transactionMonth;
	}
	@Override
	public ArrayList<OnlineBankingBean> getDailyTransaction(int date) {
		ArrayList<OnlineBankingBean> transactionDate=new ArrayList<OnlineBankingBean>();
		IonlineBankingDao ibd=new OnlineBankingDao();
		transactionDate=ibd.getTransactionDate(date);
		return transactionDate;
	}

	@Override
	public ArrayList<Long> getAccountNumbers(long useri) throws OnlineBankingException{
		// TODO Auto-generated method stub
		IonlineBankingDao ibd=new OnlineBankingDao();
		ArrayList<Long> arr=ibd.getAccountNumbers(useri);
		return arr;
	}

	@Override
	public boolean insertPayeeAccount(long user, long pid, String name) throws OnlineBankingException {
		// TODO Auto-generated method stub
		
		IonlineBankingDao ibd=new OnlineBankingDao();
		boolean res=ibd.insertPayeeAccount(user,pid,name);
		return res;
	}

	@Override
	public ArrayList<Long> getAccountNo(long user) throws OnlineBankingException {
		// TODO Auto-generated method stub
		IonlineBankingDao ibd=new OnlineBankingDao();
		 ArrayList<Long> acc=ibd.getAccountNo(user);
		return acc;
	}

	@Override
	public ArrayList<Long> getpayee(long useri) throws OnlineBankingException {
		// TODO Auto-generated method stub
		IonlineBankingDao ibd=new OnlineBankingDao();
		 ArrayList<Long> acc=ibd.getpayee(useri);
		return acc;
	
	}

	@Override
	public ArrayList<Long> getuser(long useri) throws OnlineBankingException {
		
		IonlineBankingDao ibd=new OnlineBankingDao();
		 ArrayList<Long> acc=ibd.getuser(useri);
		return acc;
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isValidPayee(long pid) throws OnlineBankingException {
		// TODO Auto-generated method stub
		IonlineBankingDao ibd=new OnlineBankingDao();
		boolean res=ibd.isValidPayee(pid);
		return res;

	}

}
