package com.onlinebanking.Dao;

public interface IQueryMapper {
	public static final String GET_ACCOUNTS = "SELECT account_no,user_id,login_password FROM user_table WHERE user_id=?";
	public static final String GET_EMAIL="SELECT EMAIL FROM CUSTOMERS WHERE ACCOUNT_NO=?";
	public static final String UPDATE_EMAIL="UPDATE CUSTOMERS SET EMAIL=? WHERE ACCOUNT_NO=? AND EMAIL=?";
	public static final String GET_ADDRESS="SELECT ADDRESS FROM CUSTOMERS WHERE ACCOUNT_NO=?";
	public static final String UPDATE_ADDRESS="UPDATE CUSTOMERS SET ADDRESS=? WHERE ACCOUNT_NO=? AND ADDRESS=?";
	public static final String RAISECHECKBOOK="INSERT INTO SERVICE_TRACKER VALUES(?,?,?,SYSDATE,?)";
	public static final String SER_SEQ_ID="SELECT SER_SEQ_ID.NEXTVAL FROM DUAL";
	public static final String SERVICE_REQUEST_DETAILS="SELECT * FROM SERVICE_TRACKER WHERE SERVICE_ID=?";
	public static final String payeeAccounts="select payee_table.payee_account_no from payee_table payee_table,user_table user_table where user_table.user_id=? and user_table.account_no=payee_table.account_no";
	public static final String updateUserAccount="UPDATE account_master set account_balance=? where account_no=?";
	public static final String accountBalance="select account_balance from account_master where account_no=?";
	public static final String updateUserTransaction="insert into transactions values(?,?,SYSDATE,?,?,?)";
	//public static final String GET_ACCOUNTNUMBERS ="SELECT account_no from payee_table where account_no=?";
	public static final String INSERTPAYEE = "insert into payee_table values(?,?,?)";
	public static final String GETACCOUNTNO = "select account_no from user_table where user_id=?";
	public static final String getpayee = "select distinct payee_table.payee_account_no from payee_table payee_table,user_table user_table where user_table.user_id=? and user_table.account_no=payee_table.account_no";
	public static final String getuser = "select account_no from user_table where user_id=?";
	public static final String getPayees = "select account_no from account_master";
	String transaction_id="select trans_seq_id.nextVal from dual";
	String transaction_password="select transaction_password from user_table where account_no=?";
	String AccountServiceDetails="SELECT * FROM SERVICE_TRACKER WHERE account_no=?";
	String CreateAccount="insert into account_master values(?,?,?,SYSDATE)";
	String AccountSequence="select seq_acc_num.nextval from dual";
	String customerDetails="insert into customer values(?,?,?,?,?)";
	String YearlyTransactions="select * from transactions where extract(year from transaction_date)=?";
	String MonthlyTransactions="select * from transactions where extract(month from transaction_date)=?";
	String DailyTransactions="select * from transactions where extract(day from transaction_date)=?";
	String PayeeDetails="select distinct account_no,payee_account_no from payee_table where account_no=?";
}
